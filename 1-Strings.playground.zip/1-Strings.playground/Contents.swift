//
//  Copyright (c) 2018 KxCoding <kky0317@gmail.com>
//
//  Permission is hereby granted, free of charge, to any person obtaining a copy
//  of this software and associated documentation files (the "Software"), to deal
//  in the Software without restriction, including without limitation the rights
//  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
//  copies of the Software, and to permit persons to whom the Software is
//  furnished to do so, subject to the following conditions:
//
//  The above copyright notice and this permission notice shall be included in
//  all copies or substantial portions of the Software.
//
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
//  THE SOFTWARE.
//
import UIKit



//let multilineString = """
//    코드 참고하며 손으로 타이핑함. \
//    탭한 곳에 3D박스가 생긴다
//    PinchGesture로 박스의 크기를 확대 축소
//    """
//
//print(multilineString)
//
//
//let testTuple = 5
//
//let rawString = #"this is\n \#(testTuple)"#
//
//print(rawString)
//
//
//let swift = "swift"
//
//
//let cha = swift[swift.index(swift.endIndex, offsetBy: -1)]
//
//swift.uppercased()
//
//swift.shuffled()
//swift.randomElement()
//swift.capitalized
//
//String(repeating: "❤️", count: 6)
//
//
//var str = "HEllo Swift"
//
//var first = str.prefix(5) // < - 메모리 공유한다.
//
//str[str.startIndex ..< str.index(str.startIndex, offsetBy: 3)]
//
//str.insert(",", at: str.firstIndex(of: "S")!)
//
//
//var str2 = "Hello, Objective-C"
//
//
//if let range = str2.range(of: "Objective-C") {
//    str2.replacingCharacters(in: range, with: "Swift")
//
//}
//
//str2.replacingOccurrences(of: "Objective-C", with: "Swift")
//
//
//let rm = str2.removeLast()
//
//rm
//str2
//
//let dr = str2.dropLast()
//
//dr
//str2
//
//
//let largeA = "Apple"
//let smallA = "apple"
//
//
//largeA.compare(smallA) == .orderedSame
//
//largeA.caseInsensitiveCompare(smallA) == .orderedSame
//
//
//largeA.compare(smallA, options: [.caseInsensitive]) == .orderedSame
//
//largeA.hasPrefix("Ap")
//
//
//let range = largeA.range(of: "pp")
//
//largeA.replacingCharacters(in: range!, with: "oo")
//
//
//
//// literal Option
//
//let a = "\u{D55C}"
//let b = "\u{1112}\u{1161}\u{11AB}"
//
//a == b
//a.compare(b) == .orderedSame
//
//a.compare(b, options: [.literal]) == .orderedSame
//
//
////  CharacterSet.uppercaseLetters
//let str3 = "loRem Ipsum"
//
//var charSet = CharacterSet.uppercaseLetters
//
//
//if let range = str3.rangeOfCharacter(from: charSet) {
//    print(str3.distance(from: str3.startIndex, to: range.lowerBound))
//}
//
//
//if let range = str3.rangeOfCharacter(from: charSet, options: [.backwards]) {
//    print(str3.distance(from: str3.startIndex, to: range.lowerBound))
//}
//
//
//let str4 = " A p p l e "
//charSet = .whitespaces
//
//str4.trimmingCharacters(in: charSet)
//
//var editTarget = CharacterSet.uppercaseLetters
//
//
//editTarget.insert("#")
//editTarget.insert(charactersIn: "~!@")
//
//editTarget.remove("A")
//editTarget.remove(charactersIn: "BCD")
//
//
//let customCharSet = CharacterSet(charactersIn: "@.")
//
//let email = "kiwan@naver.com"
//
//let arr = email.components(separatedBy: customCharSet)
//
//print(arr)



extension String{
    func getArrayAfterRegex(regex: String) -> [String] {
        
        do {
            let regex = try NSRegularExpression(pattern: regex)
            let results = regex.matches(in: self,
                                        range: NSRange(self.startIndex..., in: self))
            return results.map {
                String(self[Range($0.range, in: self)!])
            }
        } catch let error {
            print("invalid regex: \(error.localizedDescription)")
            return []
        }
    }
}


// --------------------------------------------------------------------------------------------------------
var str = "Hello  Hello #hi #Hello ##nam WOW www Hello"

// ^ : 시작되는 부분
str.getArrayAfterRegex(regex: "^Hello")

// $ : 마지막 부분
str.getArrayAfterRegex(regex: "Hello$")


// --------------------------------------------------------------------------------------------------------
str = #"$12$ \ - \ $24$"#

// \ : 뒤에 나오는 문자를 정규식에서 사용하는 키워드?가 아닌 문자로 사용
str.getArrayAfterRegex(regex: #"^\$"#)

str.getArrayAfterRegex(regex: #"\$"#)

str.getArrayAfterRegex(regex: #"\$$"#)

str.getArrayAfterRegex(regex: #"\\"#)


// --------------------------------------------------------------------------------------------------------

str = "regulation is Powerful"

// . : 와일드카드 문자로 여러개 붙어 쓸 때는 나눌수있다.
str.getArrayAfterRegex(regex: ".")

str.getArrayAfterRegex(regex: "....")


str = "O.K."

str.getArrayAfterRegex(regex: #"\."#)

str.getArrayAfterRegex(regex: #"\..\."#)

// --------------------------------------------------------------------------------------------------------

str = "How do you do?"

// [] : 스퀘어브라켓 안에 있는 문자 아무거나 매칭되는것을 찾아낸다. [] 은 하나의 문자를 표시한다.

str.getArrayAfterRegex(regex: "[oyu]")

//       한문자
// 따라서   [].  -> 2개의 문자를 나타낸다.
str.getArrayAfterRegex(regex: "[dH].")

str.getArrayAfterRegex(regex: "[oyu][yow]")


str = """
    abcdefghijklmnopqrstuvwxyz
    ABCDEFGHIJKLMNOPQRSTUVWXYZ 0123456789
    """

// [ - ] : 스퀘어브라켓 안에 하이픈은 범위를 나타내는 표현
str.getArrayAfterRegex(regex: "[c-k]")

str.getArrayAfterRegex(regex: "[a-d]")

str.getArrayAfterRegex(regex: "[2-6]")

str.getArrayAfterRegex(regex: "[C-Ka-d2-7]")

// [^ ] : 스퀘어브라켓 안에 처음에 나오는 ^은 제외한 문자를 나타내는 표현
str.getArrayAfterRegex(regex: "[^abcd]")

str.getArrayAfterRegex(regex: "[^012]")

str.getArrayAfterRegex(regex: "[^AdabdA]")

str.getArrayAfterRegex(regex: "[^W-Z]")


str = "Monday Tuesday Friday"

str.getArrayAfterRegex(regex: "(on|ues|rida)")

str.getArrayAfterRegex(regex: "(Mon|Tues|Fri)day")

str.getArrayAfterRegex(regex: "..(nd|esd|id)ay")




str = "aabc abc bc"

// * : * 앞에 나오는 문자가 없을거나 1개 이상일 경우
str.getArrayAfterRegex(regex: "a*b")

// + : + 앞에 나오는 문자가 1개 이상일 경우
str.getArrayAfterRegex(regex: "a+b")

// ? : ? 앞에 나오는 문자가 없거나 1개 일 경우
str.getArrayAfterRegex(regex: "a?b")


// 응용
str = #"-@-***--"*"--***-@-"#

str.getArrayAfterRegex(regex: ".*")

str.getArrayAfterRegex(regex: "-A*-")
 
str.getArrayAfterRegex(regex: "[-@]*")


str.getArrayAfterRegex(regex: #"\*+"#)

str.getArrayAfterRegex(regex: #"-@+-"#)


str = #"--XX-@-XX-@@-XX-@@@-XX-@@@@-XX-@@-@@-"#

str.getArrayAfterRegex(regex: "-X?XX?X")

str.getArrayAfterRegex(regex: "-@?@?@?-")



// { } : {숫자} 괄호 앞에 나오는 문자가 숫자만큼 반복
str = "One ring to bring them all and in the darkness bind them"

str.getArrayAfterRegex(regex: ".{5}")

// { , } : {앞숫자, 뒷숫자} 괄호 앞에 나오는 문자가 앞숫자 이상 뒷숫자 이하 만큼 반복
str.getArrayAfterRegex(regex: "[els]{1,3}")

str.getArrayAfterRegex(regex: "[a-z]{3,}")


// * + ? 키워드들은 { } 키워드로 변경할수있다.

str = "AA ABA ABBA ABBBA"

str.getArrayAfterRegex(regex: "AB*A")
str.getArrayAfterRegex(regex: "AB{0,}A")

str.getArrayAfterRegex(regex: "AB+A")
str.getArrayAfterRegex(regex: "AB{1,}A")

str.getArrayAfterRegex(regex: "AB?A")
str.getArrayAfterRegex(regex: "AB{0,1}A")



// 수량자 뒤에 ? 는 ? 앞 수량자 최소단위를 나타낸다.
str = "One ring to bring them all and in the darkness bind them"

str.getArrayAfterRegex(regex: "r.*")

str.getArrayAfterRegex(regex: "r.*?")


str.getArrayAfterRegex(regex: "r.+")

str.getArrayAfterRegex(regex: "r.+?")


str.getArrayAfterRegex(regex: "r.?")

str.getArrayAfterRegex(regex: "r.??")

str = "<div>test</div><div>test</div>"

str.getArrayAfterRegex(regex: "<div>.+</div>")

str.getArrayAfterRegex(regex: "<div>.+?</div>")

// \w 문자 하나를 나타내며 [A-z0-9_] 와 동일하다. - 은 포함 안된다.

str = "A1 B2 c3 d_4 e:5 ffGG77--__--"

str.getArrayAfterRegex(regex: #"\w"#)

str.getArrayAfterRegex(regex: #"[a-z]\w*"#)

str.getArrayAfterRegex(regex: #"\w{5}"#)

// \W : \w의 반대를 나타내며 [^A-z0-9_] 와 동일하다. 즉 문자가 아닌것들을 표현 (특수문자)

str = #"AS _34:AS11.23  @#$ %12^*"#

str.getArrayAfterRegex(regex: #"\W"#)


// \d : 숫자 [0-9] 와 동일
// \D : 숫자를 제외한 모든 것

str = "Page 123; published: 1234 id=12#24@112"

str.getArrayAfterRegex(regex: #"\d"#)

str.getArrayAfterRegex(regex: #"\D"#)



// \s : 스페이스, 탭, 뉴라인 문자 즉 공백을 표현
// \S : 위 공백을 제외한 모든 것
str = #"""
        Ere iron was found or tree was hewn,
        When young was mountain under moon
        Ere ring was made, or wrought was woe,
        It walked the forests long ago.
        """#

str.getArrayAfterRegex(regex: #"\s"#)
str.getArrayAfterRegex(regex: #"\S"#)


// \b : 바운더리로 문자의 경계를 나타낸다.
str.getArrayAfterRegex(regex: #"\b."#)
str.getArrayAfterRegex(regex: #".\b"#)


str.getArrayAfterRegex(regex: #"\b\w+\b"#)
str.getArrayAfterRegex(regex: #"en\b"#)

// \B : 경계가 아닌 모든곳
str.getArrayAfterRegex(regex: #"\B."#)

str.getArrayAfterRegex(regex: #".\B"#)

// \A : 문자열의 처음을 표시 (^와 다른점은 멀티라인에서 하나만표시)
// \Z : 문자열의 마지막을 표시 ($와 다른점은 멀티라인에서 하나만표시)


str.getArrayAfterRegex(regex: #"\A.."#)

str.getArrayAfterRegex(regex: #"^.."#)

str.getArrayAfterRegex(regex: #"..\Z"#)
str.getArrayAfterRegex(regex: #"..$"#)

str = "cat concat"

str.getArrayAfterRegex(regex: #"cat\b"#)

str.getArrayAfterRegex(regex: #"\B.\B"#)



// (?=<pattern>) : 페턴을 만나는순간 포함하지 안흔다.
str = "AAAXaaax---111"

str.getArrayAfterRegex(regex: #"\w+(?=X)"#)

str.getArrayAfterRegex(regex: #"\w+"#)

str.getArrayAfterRegex(regex: #"\w+(?=\w)"#)

str = #"새 폴더(222)"#



let t = str.getArrayAfterRegex(regex: #"새 폴더\(\d+\)$"#)

print(t)


str = "file_record_transcript.pdf"

str.getArrayAfterRegex(regex: #"^file.+\.pdf"#)
